BLHeliSuite uses avrdude 5.11.1 and provides a copy in it's distribution file.
For further info about avrdude see http://www.nongnu.org/avrdude/
